package com.example.financialcalculators;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons
        Button loanCalculatorButton = findViewById(R.id.btn_loan_calculator);
        Button emiCalculatorButton = findViewById(R.id.btn_emi_calculator);
        Button investmentCalculatorButton = findViewById(R.id.btn_investment_calculator);
        Button sipCalculatorButton = findViewById(R.id.btn_sip_calculator);
        Button compoundInterestCalculatorButton = findViewById(R.id.btn_compound_interest_calculator);
        Button stockReturnCalculatorButton = findViewById(R.id.btn_stock_return_calculator);
        Button retirementCalculatorButton = findViewById(R.id.btn_retirement_calculator);
        Button taxCalculatorButton = findViewById(R.id.btn_tax_calculator);
        Button currencyConverterButton = findViewById(R.id.btn_currency_converter);
        Button gstCalculatorButton = findViewById(R.id.btn_gst_calculator);

        // Set click listeners
        loanCalculatorButton.setOnClickListener(v -> showLoanCalculator());
        emiCalculatorButton.setOnClickListener(v -> showEmiCalculator());
        investmentCalculatorButton.setOnClickListener(v -> showInvestmentCalculator());
        sipCalculatorButton.setOnClickListener(v -> showSipCalculator());
        compoundInterestCalculatorButton.setOnClickListener(v -> showCompoundInterestCalculator());
        stockReturnCalculatorButton.setOnClickListener(v -> showStockReturnCalculator());
        retirementCalculatorButton.setOnClickListener(v -> showRetirementCalculator());
        taxCalculatorButton.setOnClickListener(v -> showTaxCalculator());
        currencyConverterButton.setOnClickListener(v -> showCurrencyConverter());
        gstCalculatorButton.setOnClickListener(v -> showGstCalculator());
    }

    private void showCurrencyConverter() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_currency_converter);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawableResource(android.R.color.white);

        final EditText amount = dialog.findViewById(R.id.currency_amount);
        final Spinner currencyTo = dialog.findViewById(R.id.currency_to);
        Button submitButton = dialog.findViewById(R.id.submit_button);
        Button closeButton = dialog.findViewById(R.id.close_button);
        final TextView results = dialog.findViewById(R.id.currency_results);

        // Set up the spinner with currency options
        String[] currencies = {"USD", "EUR", "GBP", "JPY", "AUD", "CAD"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, currencies);
        currencyTo.setAdapter(adapter);

        // Hardcoded exchange rates for demonstration
        final Map<String, Double> exchangeRates = new HashMap<>();
        exchangeRates.put("USD", 0.013); // Example rate: 1 INR = 0.013 USD
        exchangeRates.put("EUR", 0.012); // Example rate: 1 INR = 0.012 EUR
        exchangeRates.put("GBP", 0.011); // Example rate: 1 INR = 0.011 GBP
        exchangeRates.put("JPY", 1.55);   // Example rate: 1 INR = 1.55 JPY
        exchangeRates.put("AUD", 0.018);  // Example rate: 1 INR = 0.018 AUD
        exchangeRates.put("CAD", 0.017);  // Example rate: 1 INR = 0.017 CAD

        submitButton.setOnClickListener(v -> {
            String amountStr = amount.getText().toString().trim();

            if (amountStr.isEmpty()) {
                results.setText("Please enter an amount");
                results.setVisibility(View.VISIBLE);
                return;
            }

            double amountValue;
            try {
                amountValue = Double.parseDouble(amountStr);
            } catch (NumberFormatException e) {
                results.setText("Invalid amount entered");
                results.setVisibility(View.VISIBLE);
                return;
            }

            String currency = currencyTo.getSelectedItem().toString();

            if (exchangeRates.containsKey(currency)) {
                double convertedAmount = amountValue * exchangeRates.get(currency);
                results.setText(String.format("Converted Amount: %.2f %s", convertedAmount, currency));
            } else {
                results.setText("Currency not supported");
            }
            results.setVisibility(View.VISIBLE);
        });

        // Close Button to Dismiss the Dialog
        closeButton.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    private void showLoanCalculator() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_loan_calculator);
        dialog.setTitle("Loan Calculator");

        final EditText loanAmount = dialog.findViewById(R.id.loan_amount);
        final EditText loanInterest = dialog.findViewById(R.id.loan_interest);
        final EditText loanYears = dialog.findViewById(R.id.loan_years);
        Button calculateButton = dialog.findViewById(R.id.calculate_loan_button);
        final TextView loanResults = dialog.findViewById(R.id.loan_results);

        calculateButton.setOnClickListener(v -> {
            try {
                String loanAmountStr = loanAmount.getText().toString();
                String loanInterestStr = loanInterest.getText().toString();
                String loanYearsStr = loanYears.getText().toString();

                if (loanAmountStr.isEmpty() || loanInterestStr.isEmpty() || loanYearsStr.isEmpty()) {
                    loanResults.setText("Please fill in all fields");
                    loanResults.setVisibility(View.VISIBLE);
                    return;
                }

                double principalAmount = Double.parseDouble(loanAmountStr);
                double annualInterestRate = Double.parseDouble(loanInterestStr);
                double years = Double.parseDouble(loanYearsStr);
                double monthlyInterestRate = annualInterestRate / 100 / 12;
                int totalMonths = (int) (years * 12);

                if (monthlyInterestRate == 0) {
                    double monthlyPayment = principalAmount / totalMonths;
                    loanResults.setText(String.format("Monthly EMI: ₹%.2f\nPrincipal Amount: ₹%.2f\nTotal Interest: ₹%.2f\nTotal Amount: ₹%.2f",
                            monthlyPayment, principalAmount, 0.0, principalAmount));
                } else {
                    double monthlyPayment = principalAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalMonths) / (Math.pow(1 + monthlyInterestRate, totalMonths) - 1);
                    double totalPayment = monthlyPayment * totalMonths;
                    double totalInterest = totalPayment - principalAmount;

                    loanResults.setText(String.format("Monthly EMI: ₹%.2f\nPrincipal Amount: ₹%.2f\nTotal Interest: ₹%.2f\nTotal Amount: ₹%.2f",
                            monthlyPayment, principalAmount, totalInterest, totalPayment));
                }
                loanResults.setVisibility(View.VISIBLE);
            } catch (NumberFormatException e) {
                loanResults.setText("Invalid input");
                loanResults.setVisibility(View.VISIBLE);
            } catch (Exception e) {
                Log.e("LoanCalculator", "Error calculating loan", e);
                loanResults.setText("An error occurred");
                loanResults.setVisibility(View.VISIBLE);
            }
        });

        dialog.show();
    }

    private void showEmiCalculator() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_emi_calculator);
        dialog.setTitle("EMI Calculator");

        final EditText emiAmount = dialog.findViewById(R.id.emi_amount);
        final EditText emiInterest = dialog.findViewById(R.id.emi_interest);
        final EditText emiYears = dialog.findViewById(R.id.emi_years);
        Button calculateButton = dialog.findViewById(R.id.calculate_emi_button);
        final TextView emiResults = dialog.findViewById(R.id.emi_results);

        calculateButton.setOnClickListener(v -> {
            try {
                String amountStr = emiAmount.getText().toString();
                String interestStr = emiInterest.getText().toString();
                String yearsStr = emiYears.getText().toString();

                if (amountStr.isEmpty() || interestStr.isEmpty() || yearsStr.isEmpty()) {
                    emiResults.setText("Please fill in all fields");
                    emiResults.setVisibility(View.VISIBLE);
                    return;
                }

                double amount = Double.parseDouble(amountStr);
                double interest = Double.parseDouble(interestStr) / 100 / 12; // Monthly interest
                double months = Double.parseDouble(yearsStr) * 12; // Total months

                if (interest == 0) {
                    double monthlyPayment = amount / months;
                    emiResults.setText(String.format("Monthly Payment: ₹%.2f\nTotal Payment: ₹%.2f",
                            monthlyPayment, monthlyPayment * months));
                } else {
                    double monthlyPayment = amount * interest * Math.pow(1 + interest, months) / (Math.pow(1 + interest, months) - 1);
                    double totalPayment = monthlyPayment * months;
                    double totalInterest = totalPayment - amount;

                    emiResults.setText(String.format("Monthly Payment: ₹%.2f\nTotal Payment: ₹%.2f\nTotal Interest: ₹%.2f",
                            monthlyPayment, totalPayment, totalInterest));
                }
                emiResults.setVisibility(View.VISIBLE);
            } catch (NumberFormatException e) {
                emiResults.setText("Invalid input");
                emiResults.setVisibility(View.VISIBLE);
            }
        });

        dialog.show();
    }

    private void showTaxCalculator() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_tax_calculator);
        dialog.setTitle("Tax Calculator");

        final EditText income = dialog.findViewById(R.id.tax_income);
        final EditText taxPercentage = dialog.findViewById(R.id.tax_percentage);
        Button calculateButton = dialog.findViewById(R.id.calculate_tax_button);
        final TextView results = dialog.findViewById(R.id.tax_results);

        calculateButton.setOnClickListener(v -> {
            try {
                String incomeStr = income.getText().toString();
                String taxPercentageStr = taxPercentage.getText().toString();

                if (incomeStr.isEmpty() || taxPercentageStr.isEmpty()) {
                    results.setText("Please fill in all fields");
                    results.setVisibility(View.VISIBLE);
                    return;
                }

                double annualIncome = Double.parseDouble(incomeStr);
                double taxRate = Double.parseDouble(taxPercentageStr) / 100;
                double taxLiability = annualIncome * taxRate;

                if (Double.isFinite(taxLiability)) {
                    results.setText(String.format("Total Tax Liability: ₹%.2f", taxLiability));
                } else {
                    results.setText("Please check your numbers");
                }
                results.setVisibility(View.VISIBLE);
            } catch (NumberFormatException e) {
                results.setText("Invalid input");
                results.setVisibility(View.VISIBLE);
            }
        });

        dialog.show();
    }

    private void showInvestmentCalculator() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_investment_calculator);
        dialog.setTitle("Investment Calculator");

        final EditText investmentAmount = dialog.findViewById(R.id.investment_amount);
        final EditText investmentInterest = dialog.findViewById(R.id.investment_interest);
        final EditText investmentYears = dialog.findViewById(R.id.investment_years);
        Button calculateButton = dialog.findViewById(R.id.calculate_investment_button);
        final TextView investmentResults = dialog.findViewById(R.id.investment_results);

        calculateButton.setOnClickListener(v -> {
            try {
                String amountStr = investmentAmount.getText().toString();
                String interestStr = investmentInterest.getText().toString();
                String yearsStr = investmentYears.getText().toString();

                if (amountStr.isEmpty() || interestStr.isEmpty() || yearsStr.isEmpty()) {
                    investmentResults.setText("Please fill in all fields");
                    investmentResults.setVisibility(View.VISIBLE);
                    return;
                }

                double amount = Double.parseDouble(amountStr);
                double interestRate = Double.parseDouble(interestStr) / 100;
                double years = Double.parseDouble(yearsStr);

                double totalValue = amount * Math.pow(1 + interestRate, years);

                if (Double.isFinite(totalValue)) {
                    investmentResults.setText(String.format("Total Value after %.0f years: ₹%.2f", years, totalValue));
                } else {
                    investmentResults.setText("Please check your numbers");
                }
                investmentResults.setVisibility(View.VISIBLE);
            } catch (NumberFormatException e) {
                investmentResults.setText("Invalid input");
                investmentResults.setVisibility(View.VISIBLE);
            }
        });

        dialog.show();
    }

    private void showSipCalculator() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_sip_calculator);
        dialog.setTitle("SIP Calculator");

        final EditText sipAmount = dialog.findViewById(R.id.sip_amount);
        final EditText sipInterest = dialog.findViewById(R.id.sip_interest);
        final EditText sipYears = dialog.findViewById(R.id.sip_years);
        Button calculateButton = dialog.findViewById(R.id.calculate_sip_button);
        final TextView sipResults = dialog.findViewById(R.id.sip_results);

        calculateButton.setOnClickListener(v -> {
            try {
                String monthlyInvestmentStr = sipAmount.getText().toString();
                String annualReturnStr = sipInterest.getText().toString();
                String yearsStr = sipYears.getText().toString();

                if (monthlyInvestmentStr.isEmpty() || annualReturnStr.isEmpty() || yearsStr.isEmpty()) {
                    sipResults.setText("Please fill in all fields");
                    sipResults.setVisibility(View.VISIBLE);
                    return;
                }

                double monthlyInvestment = Double.parseDouble(monthlyInvestmentStr);
                double annualReturn = Double.parseDouble(annualReturnStr) / 100;
                double years = Double.parseDouble(yearsStr);
                double months = years * 12;

                double futureValue = monthlyInvestment *
                        ((Math.pow(1 + annualReturn / 12, months) - 1) / (annualReturn / 12)) *
                        Math.pow(1 + annualReturn / 12, months);

                if (Double.isFinite(futureValue)) {
                    sipResults.setText(String.format("Total SIP Value after %.0f years: ₹%.2f", years, futureValue));
                } else {
                    sipResults.setText("Please check your numbers");
                }
                sipResults.setVisibility(View.VISIBLE);
            } catch (NumberFormatException e) {
                sipResults.setText("Invalid input");
                sipResults.setVisibility(View.VISIBLE);
            }
        });

        dialog.show();
    }

    private void showCompoundInterestCalculator() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_compound_interest_calculator);
        dialog.setTitle("Compound Interest Calculator");

        final EditText principal = dialog.findViewById(R.id.compound_principal);
        final EditText rate = dialog.findViewById(R.id.compound_rate);
        final EditText times = dialog.findViewById(R.id.compound_times);
        final EditText years = dialog.findViewById(R.id.compound_years);
        Button calculateButton = dialog.findViewById(R.id.calculate_compound_button);
        final TextView results = dialog.findViewById(R.id.compound_results);

        calculateButton.setOnClickListener(v -> {
            try {
                String principalStr = principal.getText().toString();
                String rateStr = rate.getText().toString();
                String timesStr = times.getText().toString();
                String yearsStr = years.getText().toString();

                if (principalStr.isEmpty() || rateStr.isEmpty() || timesStr.isEmpty() || yearsStr.isEmpty()) {
                    results.setText("Please fill in all fields");
                    results.setVisibility(View.VISIBLE);
                    return;
                }

                double principalAmount = Double.parseDouble(principalStr);
                double annualRate = Double.parseDouble(rateStr) / 100;
                double timesCompounded = Double.parseDouble(timesStr);
                double yearsAmount = Double.parseDouble(yearsStr);

                double compoundAmount = principalAmount *
                        Math.pow(1 + annualRate / timesCompounded, timesCompounded * yearsAmount);

                if (Double.isFinite(compoundAmount)) {
                    results.setText(String.format("Total Amount after %.0f years: ₹%.2f", yearsAmount, compoundAmount));
                } else {
                    results.setText("Please check your numbers");
                }
                results.setVisibility(View.VISIBLE);
            } catch (NumberFormatException e) {
                results.setText("Invalid input");
                results.setVisibility(View.VISIBLE);
            }
        });

        dialog.show();
    }

    private void showStockReturnCalculator() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_stock_return_calculator);
        dialog.setTitle("Stock Return Calculator");

        final EditText purchasePrice = dialog.findViewById(R.id.stock_purchase_price);
        final EditText sellPrice = dialog.findViewById(R.id.stock_sell_price);
        final EditText quantity = dialog.findViewById(R.id.stock_quantity);
        Button calculateButton = dialog.findViewById(R.id.calculate_stock_button);
        final TextView results = dialog.findViewById(R.id.stock_results);

        calculateButton.setOnClickListener(v -> {
            try {
                String purchaseStr = purchasePrice.getText().toString();
                String sellStr = sellPrice.getText().toString();
                String quantityStr = quantity.getText().toString();

                if (purchaseStr.isEmpty() || sellStr.isEmpty() || quantityStr.isEmpty()) {
                    results.setText("Please fill in all fields");
                    results.setVisibility(View.VISIBLE);
                    return;
                }

                double purchase = Double.parseDouble(purchaseStr);
                double sell = Double.parseDouble(sellStr);
                double qty = Double.parseDouble(quantityStr);

                double totalReturn = (sell - purchase) * qty;

                if (Double.isFinite(totalReturn)) {
                    results.setText(String.format("Total Return: ₹%.2f", totalReturn));
                } else {
                    results.setText("Please check your numbers");
                }
                results.setVisibility(View.VISIBLE);
            } catch (NumberFormatException e) {
                results.setText("Invalid input");
                results.setVisibility(View.VISIBLE);
            }
        });

        dialog.show();
    }

    private void showRetirementCalculator() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_retirement_calculator);
        dialog.setTitle("Retirement Calculator");

        final EditText currentAge = dialog.findViewById(R.id.retirement_age);
        final EditText retirementAge = dialog.findViewById(R.id.retirement_age_at);
        final EditText monthlySavings = dialog.findViewById(R.id.retirement_monthly_savings);
        final EditText annualReturn = dialog.findViewById(R.id.retirement_interest);
        Button calculateButton = dialog.findViewById(R.id.calculate_retirement_button);
        final TextView results = dialog.findViewById(R.id.retirement_results);

        calculateButton.setOnClickListener(v -> {
            try {
                String ageNowStr = currentAge.getText().toString();
                String ageRetirementStr = retirementAge.getText().toString();
                String savingsStr = monthlySavings.getText().toString();
                String returnRateStr = annualReturn.getText().toString();

                if (ageNowStr.isEmpty() || ageRetirementStr.isEmpty() || savingsStr.isEmpty() || returnRateStr.isEmpty()) {
                    results.setText("Please fill in all fields");
                    results.setVisibility(View.VISIBLE);
                    return;
                }

                double ageNow = Double.parseDouble(ageNowStr);
                double ageRetirement = Double.parseDouble(ageRetirementStr);
                double savings = Double.parseDouble(savingsStr);
                double returnRate = Double.parseDouble(returnRateStr) / 100;

                double yearsUntilRetirement = ageRetirement - ageNow;
                double months = yearsUntilRetirement * 12;
                double futureValue = savings *
                        ((Math.pow(1 + returnRate / 12, months) - 1) / (returnRate / 12)) *
                        Math.pow(1 + returnRate / 12, months);

                if (Double.isFinite(futureValue)) {
                    results.setText(String.format("Total Savings at Retirement: ₹%.2f", futureValue));
                } else {
                    results.setText("Please check your numbers");
                }
                results.setVisibility(View.VISIBLE);
            } catch (NumberFormatException e) {
                results.setText("Invalid input");
                results.setVisibility(View.VISIBLE);
            }
        });

        dialog.show();
    }

    private void showGstCalculator() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_gst_calculator);
        dialog.setTitle("GST Calculator");

        final EditText amount = dialog.findViewById(R.id.gst_amount);
        final EditText gstRate = dialog.findViewById(R.id.gst_rate);
        Button calculateButton = dialog.findViewById(R.id.calculate_gst_button);
        final TextView results = dialog.findViewById(R.id.gst_results);

        calculateButton.setOnClickListener(v -> {
            try {
                String amountStr = amount.getText().toString();
                String gstRateStr = gstRate.getText().toString();

                if (amountStr.isEmpty() || gstRateStr.isEmpty()) {
                    results.setText("Please fill in all fields");
                    results.setVisibility(View.VISIBLE);
                    return;
                }

                double amountValue = Double.parseDouble(amountStr);
                double gstRateValue = Double.parseDouble(gstRateStr) / 100;

                double gstAmount = amountValue * gstRateValue;
                double totalAmount = amountValue + gstAmount;

                if (Double.isFinite(totalAmount)) {
                    results.setText(String.format("Total Amount after GST: ₹%.2f", totalAmount));
                } else {
                    results.setText("Please check your numbers");
                }
                results.setVisibility(View.VISIBLE);
            } catch (NumberFormatException e) {
                results.setText("Invalid input");
                results.setVisibility(View.VISIBLE);
            }
        });

        dialog.show();
    }
}
