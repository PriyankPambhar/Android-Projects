package com.example.financialcalculators;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface CurrencyApiService {
    @GET("latest")
    Call<CurrencyResponse> getExchangeRates(@Query("apikey") String apiKey);
}
